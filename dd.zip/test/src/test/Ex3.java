package test;

public class Ex3 {

	public static void main(String[] args) {
		int top = 10;
		int bottom = 15;
		int height = 11;
		System.out.println((top+bottom)/(double)2*height);

	}

}
