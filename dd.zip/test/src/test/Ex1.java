package test;

public class Ex1 {

	public static void main(String[] args) {
		int sample = 678;
		System.out.println("백단위 자리는 " + (sample/100)*100 + " 입니다.");

	}

}
