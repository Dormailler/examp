package test;

public class Ex4 {

	public static void main(String[] args) {
		int time = 10000;
		System.out.println(time+" 초는 " + time/60/60 +
			"시간 " + time / 60 % 60 + "분 " + time%60 +"초입니다.");

	}

}
